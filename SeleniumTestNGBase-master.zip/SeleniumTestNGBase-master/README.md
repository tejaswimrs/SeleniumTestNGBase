# TestNG
Functional testing framework using Selenium WebDriver and TestNG on mytestinglabs.in by prasanna

# Push Your code with the help of following git commands

git checkout -b <branch-name>
  
git remote add upstream https://github.com/pvpsuman/SeleniumTestNGBase.git

git add <filename>

git commit -m "<message>"

git push --set-upstream origin <branch-name>

# Usage
 Goto src\test\resources\config.properties and update the configuration values according to your preferences
 
 Add TestNG functions in the test packages
 
 Add Selenium Actions related code to the pages package.
 
 # Note: Implement in the automation script using Page Object Modal
