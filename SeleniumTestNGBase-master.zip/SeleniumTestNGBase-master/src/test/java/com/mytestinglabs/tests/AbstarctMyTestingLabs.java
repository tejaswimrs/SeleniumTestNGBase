package com.mytestinglabs.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.mytestinglabs.pages.BrowserFactory;
import com.mytestinglabs.pages.TestConstants;

public abstract class AbstarctMyTestingLabs {
	
	
	protected static Properties config;
	protected final Logger LOG = LoggerFactory.getLogger(AbstarctMyTestingLabs.class);
	protected static String curr_dir;
	protected static TestConstants test_cons = new TestConstants();
	protected static WebDriver driver;
	protected static String BASE_URL;
	protected static String BROWSER;
	protected static String CLIENT;
	protected static String RETRY;
	protected static String MODE;
	protected static String GROUP;
	protected static String REMOTE_URL;
	
	@BeforeSuite(alwaysRun = true)
	public void beforesuite()
	{
		
		LOG.info("Started Suite");
		try
		{
			config = new Properties();
			LOG.info(ClassLoader.getSystemResource("config.properties").getFile());
			curr_dir = System.getProperty("user.dir");
			FileInputStream fn = new FileInputStream(ClassLoader.getSystemResource("config.properties").getFile());
			config.load(fn);
			System.out.println("BASE URL NAME: " + System.getProperty("baseurl.name"));
			if (System.getProperty("baseurl.name") == null)
			{
				BASE_URL = config.getProperty("BASE_URL");
			}
			else
			{
				BASE_URL = System.getProperty("baseurl.name");
				config.setProperty("BASE_URL",BASE_URL);
			}
			System.out.println("Browser NAME: " + System.getProperty("browser.name"));
			if (System.getProperty("browser.name") == null)
			{
				BROWSER = config.getProperty("BROWSER");
			}
			else
			{
				BROWSER = System.getProperty("browser.name");
				config.setProperty("BROWSER",BROWSER);
			}
			System.out.println("CLIENT NAME: " + System.getProperty("client.name"));
			if (System.getProperty("client.name") == null)
			{
				CLIENT = config.getProperty("CLIENT");
			}
			else
			{
				CLIENT = System.getProperty("client.name");
				config.setProperty("CLIENT",CLIENT);
			}
			System.out.println("RETRY COUNT: " + System.getProperty("retry.count"));
			if (System.getProperty("retry.count") == null)
			{
				RETRY = config.getProperty("RETRYCOUNT");
			}
			else
			{
				RETRY = System.getProperty("retry.count");
				config.setProperty("RETRYCOUNT",RETRY);
			}
			System.out.println("SELENIUM SERVER URL: " + System.getProperty("remoteurl.name"));
			if (System.getProperty("remoteurl.name") == null)
			{
				REMOTE_URL = config.getProperty("REMOTE_URL");
			}
			else
			{
				REMOTE_URL = System.getProperty("remoteurl.name");
				config.setProperty("REMOTE_URL",REMOTE_URL);
			}
			driver = BrowserFactory.getBrowser(BROWSER, CLIENT, REMOTE_URL);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get(BASE_URL);

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	

	@AfterSuite(alwaysRun = true)
	public void aftersuite()
	{
		if(config.getProperty("BROWSER").equals("Chrome"))
		{
			try {
				Runtime.getRuntime().exec("/bin/bash -c killall chromedriver");
			} catch (IOException ignored) {
				LOG.error("Unable to kill chromedriver. Please kill chromedriver manually.");
			}
		}
		
		closeDriver();
		LOG.info("Exiting Suite");
	}		

	public WebDriver getDriver() {
	   return driver;
	}
	
	public void closeDriver() {
		driver.close();
		driver.quit();
	}

}
