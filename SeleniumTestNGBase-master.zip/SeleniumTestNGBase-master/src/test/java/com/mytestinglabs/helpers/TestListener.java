package com.mytestinglabs.helpers;



import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;

import com.mytestinglabs.tests.AbstarctMyTestingLabs;

public  class TestListener implements ITestListener {
	
	final Logger LOG = LoggerFactory.getLogger(TestListener.class);
	
    @Override
    public void onTestFailure(ITestResult result) {
    	LOG.error("***** Error "+result.getName()+" test has failed *****");
    	Object currentClass = result.getInstance();
        WebDriver webDriver = ((AbstarctMyTestingLabs) currentClass).getDriver();
    	String className = result.getClass().getName().toString().trim();
    	String methodName = result.getMethod().getMethodName().toString().trim();
    	System.out.println("dummy test suman" + webDriver);
    	ScreenshotCapture.takescreenshot(webDriver, className, methodName);
    }
    
    @Override
	public void onFinish(ITestContext context) {
		Set<ITestResult> failedTests = context.getFailedTests().getAllResults();
		for (ITestResult temp : failedTests) {
			ITestNGMethod method = temp.getMethod();
			if (context.getFailedTests().getResults(method).size() > 1) {
				failedTests.remove(temp);
			} else {
				if (context.getPassedTests().getResults(method).size() > 0) {
					failedTests.remove(temp);
				}
			}
		}
	}
  
    @Override
    public void onTestStart(ITestResult result) { 
    	LOG.info("***** Testcase "+result.getName()+" has started *****");
    }
    
    @Override
    public void onTestSuccess(ITestResult result) {   
    	LOG.info("***** Testcase "+result.getName()+" has Passed *****");
    }

    @Override
    public void onTestSkipped(ITestResult result) { 
    	LOG.info("***** Testcase "+result.getName()+" has been Skipped *****");
    }

    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {   }

    public void onStart(ITestContext context) {   }
}  