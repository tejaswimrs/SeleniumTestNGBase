package com.mytestinglabs.helpers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

 
/**
 * This program demonstrates how to capture a screenshot (full screen)
 * as an image which will be saved into a file.
 *
 */
public class ScreenshotCapture {
	private static String currentDir = null;
	final static Logger LOG = LoggerFactory.getLogger(ScreenshotCapture.class);
	static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
    static Date date = new Date();
    static String curr_dir = System.getProperty("user.dir");
    public static void takescreenshot (WebDriver driver, String className, String methodName) {
    	
    	    try {
    	      currentDir = new File(".").getCanonicalPath();
    	    } catch (IOException e) {
    	      LOG.info("Error while detecting current working dir. Reason:"+e.getMessage());
    	    }
    	 
    	
    	if ( driver == null){
    	     LOG.info( String.format("The test class '%s' does not have any field of type 'org.openqa.selenium.WebDriver'. " +
    	              "ScreenshotTestListener can not continue.", className));
    	      return;
    	    }

    	    File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	    try {
    	       Path screenshotPath = Paths.get(currentDir, "Screenshot", methodName + "_"+ dateFormat.format(date)+".png");
    	      LOG.info("copying "+screenshotPath);
    	      Files.copy(f.toPath(),screenshotPath, StandardCopyOption.REPLACE_EXISTING);
    	    } catch (IOException e) {
    	      LOG.info("error during the screenshot copy file operation:" + e.getMessage());
    	    }
    
    	
    }
}