package com.mytestinglabs.pages;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BrowserFactory {
	static String curr_dir = System.getProperty("user.dir");
	protected final static Logger LOG = LoggerFactory.getLogger(BrowserFactory.class);
	private static boolean isSupportedPlatform(String OS) {
		Platform current = Platform.getCurrent();
		LOG.info("***************Getting Current Platform*******************");
		LOG.info("Current: " + current);
		if (OS == "MAC")
			return Platform.MAC.is(current);
		else if (OS == "LINUX")
			return	Platform.LINUX.is(current);
		else if (OS == "XP")
			return	Platform.XP.is(current);
		else 
			return	Platform.WIN8.is(current);
	}
	
	
	/*
	 * Factory method for getting browsers
	 */
	public static WebDriver getBrowser(String browserName,String client_type, String selenium_server_url) {

		switch (browserName) {

		case "Firefox":
			if(client_type.equals("LOCAL"))
			{
				return new FirefoxDriver();
			}
			else if(client_type.equals("REMOTE"))
			{
				DesiredCapabilities cap1 = DesiredCapabilities.firefox();
				try {
					// ip of the Server
					return new RemoteWebDriver(new URL(selenium_server_url), cap1);
				} catch (MalformedURLException e) {
					throw new RuntimeException("Error while creating remote web driver", e);
				}
			}

		case "IE":
			if(isSupportedPlatform("WINDOWS"))
			{
				System.setProperty("webdriver.ie.driver",
						ClassLoader.getSystemResource("IEDriverServer.exe").getFile());
				return new InternetExplorerDriver();
			}
			throw new RuntimeException("Cannot use IE if platform is not Windows");

		case "Chrome":
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");
			DesiredCapabilities cap = DesiredCapabilities.chrome();
			cap.setCapability(ChromeOptions.CAPABILITY, options);
			cap.setBrowserName("chrome");
			if(client_type.equals("LOCAL") && isSupportedPlatform("MAC"))
			{	

				System.setProperty("webdriver.chrome.driver",curr_dir + "/src/test/resources/drivers/mac/chromedriver");
				return new ChromeDriver();
			}
			else if (client_type.equals("LOCAL") && isSupportedPlatform("XP"))
			{
				System.setProperty("webdriver.chrome.driver",curr_dir + "\\src\\test\\resources\\drivers\\windows\\chromedriver.exe");
				return new ChromeDriver();
			}
			else if (client_type.equals("LOCAL") && isSupportedPlatform("WINDOWS"))
			{
				System.setProperty("webdriver.chrome.driver",curr_dir + "\\src\\test\\resources\\drivers\\windows\\chromedriver.exe");
				return new ChromeDriver();
			} else if(client_type.equals("LOCAL") && isSupportedPlatform("LINUX"))
			{	
				System.setProperty("webdriver.chrome.driver",curr_dir + "/src/test/resources/drivers/linux/chromedriver");
				return new ChromeDriver();
			} else if(client_type.equals("REMOTE"))
			{	
				try {
					return new RemoteWebDriver(new URL(selenium_server_url), cap);
				} catch (MalformedURLException e) {
					throw new RuntimeException("Error while creating remote web driver", e);
				}
			}

		case "Safari":
			if(isSupportedPlatform("MAC"))
			{
				return new SafariDriver();
			}
			
		}
		throw new RuntimeException("Unable to create driver instance");
	}

}
