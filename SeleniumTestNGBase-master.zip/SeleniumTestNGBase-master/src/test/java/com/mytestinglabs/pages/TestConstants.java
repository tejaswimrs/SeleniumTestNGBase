package com.mytestinglabs.pages;

public class TestConstants {
	
	public static final String userEmail = "pvpsuman@gmail.com";
	public static final String invalidEmail = "pvpsuman@gmail.co.in";
	public static final String invalidFormatEmail = "pvpsuman";

}
