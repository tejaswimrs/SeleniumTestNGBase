package com.mytestinglabs.utils;

import org.openqa.selenium.WebElement;

public class ElementActions {
	
	public static void clearAndSetText(WebElement ele, String value) {
		ele.clear();
		ele.sendKeys(value);
	}

}
