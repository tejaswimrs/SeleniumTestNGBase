package com.mytestinglabs.utils;

public class ErrorMessages {

}
