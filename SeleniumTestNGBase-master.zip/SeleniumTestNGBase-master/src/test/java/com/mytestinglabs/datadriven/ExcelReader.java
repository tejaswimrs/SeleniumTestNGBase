package com.mytestinglabs.datadriven;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.DataProvider;


public class ExcelReader {
	
	protected final static Logger LOG = LoggerFactory.getLogger(ExcelReader.class);
	

	public static FileInputStream getFISObject(String fileName){
		File file = getFileObject(fileName);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file );
		} catch (FileNotFoundException e) {
		}
		return fis;		
	}

	public static File getFileObject(String fileName){
		String filePath = ClassLoader.getSystemResource(fileName).getFile();
		return new File(filePath);
	}


	public static HSSFSheet getWorkbookSheetObject(String fileName,String sheetName){
		FileInputStream fis = getFISObject(fileName);
		HSSFWorkbook wb = null;
		try {
			wb = new HSSFWorkbook(fis);
		} 
		catch (IOException e) {
		}
		HSSFSheet sheet = wb.getSheet(sheetName);
		return sheet;		
	}

	public static HSSFWorkbook getWorkbookObject(String fileName){
		FileInputStream fis = getFISObject(fileName);
		HSSFWorkbook wb = null;
		try {
			wb = new HSSFWorkbook(fis);
		} catch (IOException e) {
		}
		return wb;
	}

	public static HSSFWorkbook getWorkBookObject(FileInputStream fis){
		HSSFWorkbook wb = null;
		try {
			wb = new HSSFWorkbook(fis);
		} catch (IOException e) {
		}
		return wb;	
	}

	public static void closeWorkbook(HSSFWorkbook wb){
		try {
			wb.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static int getStartingRow(String fileName,String sheetName,String tagName){	
		int startingRow = 0;	
		HSSFWorkbook wb = getWorkbookObject(fileName);
		HSSFSheet sheet = wb.getSheet(sheetName);
		int totalNoOfRecords = sheet.getLastRowNum();
		for (int i = 0; i <= totalNoOfRecords; i++) {
			HSSFRow row = sheet.getRow(i);
			if(row !=null){ 
				if(row.getCell(0).getStringCellValue().contains(tagName)){
					startingRow = row.getRowNum() + 1;
					return startingRow;
				}
			}
		}
		closeWorkbook(wb);
		throw new RuntimeException("The tag Name " + tagName + " does not exist");
	}

	public static <T> T getCellValue(HSSFCell cell){
		Object value = null;
		switch(cell.getCellType())
		{
		case Cell.CELL_TYPE_BOOLEAN:
			value = cell.getBooleanCellValue();
			break;

		case Cell.CELL_TYPE_NUMERIC:
			value = cell.getNumericCellValue();
			break;
			
		case Cell.CELL_TYPE_STRING:
			value = cell.getStringCellValue();
			break;
		}
		return (T)value;
	}

	public static int getEndingRow(String fileName,String sheetName,String tagName){
		int endingRow = 0;
		HSSFWorkbook wb = getWorkbookObject(fileName);
		HSSFSheet sheet = wb.getSheet(sheetName);
		int totalNoOfRecords = sheet.getLastRowNum();
		for (int i = 0; i <= totalNoOfRecords; i++) {
			HSSFRow row = sheet.getRow(i);
			if(row !=null){
				HSSFCell lastCellForEachRow = row.getCell(row.getLastCellNum() - 1);
				if(lastCellForEachRow != null && lastCellForEachRow.getStringCellValue().contains(tagName)){
					endingRow = row.getRowNum();
					return endingRow;
				}
			}
		}
		closeWorkbook(wb);
		throw new RuntimeException("The tag Name " + tagName + " does not exist");
	}
	
	
	public static String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			LOG.info("Got File object: " + fs.toString() + "FileName: " + fileName + "SheetName: " + sheetName);
			Workbook wb = Workbook.getWorkbook(fs);
			LOG.info("Got WorkBook object: " + wb.toString());
			Sheet sh = wb.getSheet(sheetName);
			LOG.info("Got Sheet object: " + sh.toString());
			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			LOG.info("Column: " + totalNoOfCols + "Rows: " + totalNoOfRows);
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) {

				for (int j=0; j < totalNoOfCols; j++) {
					
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}
	
	public static String getExcelFileName(Method m)
	{
		Excel excelAnnotation = m.getAnnotation(Excel.class);
		if(excelAnnotation!=null) {
			return excelAnnotation.file();
		}
		return null;
	}

	public static String getExcelSheetName(Method m)
	{
		Excel excelAnnotation = m.getAnnotation(Excel.class);
		if(excelAnnotation!=null) {
			return excelAnnotation.sheet();
		}
		return null;
	}

	public static String getExcelTableName(Method m)
	{
		Excel excelAnnotation = m.getAnnotation(Excel.class);
		if(excelAnnotation!=null) {
			return excelAnnotation.table();
		}
		return null;
	}
}
