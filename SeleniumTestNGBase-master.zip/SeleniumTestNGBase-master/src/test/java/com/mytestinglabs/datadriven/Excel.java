package com.mytestinglabs.datadriven;

import static java.lang.annotation.ElementType.METHOD;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;


@Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@Target(METHOD)
@Documented
public @interface Excel {
	String file();
	String sheet();
	String table();
}