package com.mytestinglabs.datadriven;

import org.testng.annotations.DataProvider;

public class ExcelData {
	
	private static String curr_dir = System.getProperty("user.dir");
	
	@DataProvider(name="dummyDates")
	public static Object[][] pincodeDataWardrobe() {
		Object[][] arrayObject = ExcelReader.getExcelData(curr_dir + "/src/test/resources/DummyDates.xls","Dates");
		return arrayObject;	
	}

}
